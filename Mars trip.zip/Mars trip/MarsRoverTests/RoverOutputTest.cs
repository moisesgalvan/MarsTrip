using System;
using Xunit;
using MarsRover;

namespace MarsRoverTests
{
    public class RoverOutputTest
    {
        [Fact]
        public void executeInstruction()
        {
            // ===================== TEST 1 ===================== //

            //Arrange
            Rover rover = new Rover("1 2 N", "5 5");

            //Act
            rover.executeInstruction("LMLMLMLMM");

            //Assert
            Assert.Equal("1 3 N", rover.x + " " + rover.y + " " + rover.direction);
            
            // ===================== TEST 2 ===================== //

            //Arrange
            rover = new Rover("3 3 E", "5 5");

            //Act
            rover.executeInstruction("MMRMMRMRRM");

            //Assert
            Assert.Equal("5 1 E", rover.x + " " + rover.y + " " + rover.direction);
        }
    }
}
