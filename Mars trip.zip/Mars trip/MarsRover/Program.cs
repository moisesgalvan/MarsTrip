﻿using System;

namespace MarsRover
{
    class Program
    {
        static void Main(string[] args)
        {

            do
            {
                Console.WriteLine("Input: Enter Bounds *Please add a space after each bound -> (X Y) ");

                string bounds = Console.ReadLine();


                Console.WriteLine("\nInput: Enter Initial Location *Please add a space after each Character and allowed directions are (N,S,E or W)-> (x y E)");
                string coordinates = Console.ReadLine().ToUpper();

                if (coordinates.Length != 5)
                {
                    Console.WriteLine("Invalid Coordinates");
                    break;

                }

                var currRover = new Rover(coordinates, bounds);

                Console.WriteLine("\nInput: Please enter Rover's commands *Add a space after each Character and allowed format L = left, R = right, M = move");
                string coms = Console.ReadLine();

                Boolean isValid = currRover.executeInstruction(coms);

                if (!isValid)
                {
                    break;
                }


                Console.WriteLine("\nFinal Location:");
                Console.WriteLine(currRover.x + " " + currRover.y + " " + currRover.direction);

                Console.Write("\nEnter 'y' to continue , if you enter anything else then you will be exited from the rover handling ");
                string answer = Console.ReadLine();
                if (!answer.Equals("y"))
                {
                    break;
                }


            } while (true);

            Console.WriteLine("\n -------------- The rover has been handled properly, You are such a good Spaceman! --------------  ");

        }
    }
}
