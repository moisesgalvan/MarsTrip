﻿using System;

namespace MarsRover
{
    public class Rover
    {
        public int x; 
        public int y; 
        public int xGrig;
        public int yGrid; 
        public string roverDirection; 
        

        public Rover(string location, string bounds)
        {
            Int32.TryParse(location.Split(" ")[0], out x);
            Int32.TryParse(location.Split(" ")[1], out y);
            roverDirection = location.Split(" ")[2];

            Int32.TryParse(bounds.Split(" ")[0], out xGrig);
            Int32.TryParse(bounds.Split(" ")[1], out yGrid);
        }

        public Boolean executeInstruction(string command) 
        {
            Char[] instructions = command.ToCharArray();

            Console.WriteLine(xGrig + " " + yGrid);

            if(xGrig < 0 || yGrid < 0)
            {
                Console.WriteLine("Invalid Grid Size!!");
                return false;
            }

            if (roverDirection != "N" && roverDirection != "S" && roverDirection != "E" && roverDirection != "W")
            {
                Console.WriteLine("Invalid Direction, please use something within: N,S,E,W");
                return false;
            }

            if(x > xGrig || y > yGrid)
            {
                Console.WriteLine("Rover moved out of Grid");
                return false;
            }

            for (int i = 0; i < instructions.Length; i++)
            {
                switch (instructions[i])
                {
                    case 'L':
                        if (TurnLeft() == -1)
                        {
                            return false;
                        }
                        break;
                    case 'R':
                        if (TurnRight() == -1)
                        {
                            return false;
                        }
                        break;
                    case 'M':
                        if (MoveForward() == -1)
                        {
                            return false;
                        }

                        break;
                    default:
                        Console.WriteLine("Invalid move! Valid moves are 'L','R','M'. Please try again!");
                        return false;

                }

            }
            return true;

        }

        //Move rover into forward direction

        public int MoveForward()
        {
            switch (roverDirection)
            {
                case "N":
                    y += 1;
                    if (y > yGrid || y < 0)
                    {
                        Console.WriteLine("Rover moved out of Grid");
                        return -1;
                    }
                    break;
                case "E":
                    x += 1;
                    if (x > xGrig || x < 0)
                    {
                        Console.WriteLine("Rover moved out of Grid");
                        return -1;
                    }
                    break;
                case "S":
                    y -= 1;
                    if (y > yGrid || y < 0)
                    {
                        Console.WriteLine("Rover moved out of Grid");
                        return -1;
                    }
                    break;
                case "W":
                    x -= 1;
                    if (x > xGrig || x < 0)
                    {
                        Console.WriteLine("Rover moved out of Grid");
                        return -1;
                    }
                    break;

                default:
                    throw new ArgumentException();
            }
            return 1;
        }

       //Move rover into right direction

        public int TurnRight()
        {
            switch (roverDirection)
            {
                case "N":
                    roverDirection = "E";
                    break;
                case "E":
                    roverDirection = "S";
                    break;
                case "S":
                    roverDirection = "W";
                    break;
                case "W":
                    roverDirection = "N";
                    break;

                default:
                    Console.WriteLine("Invalid Direction. Valid Directions are: 'N','S','E','W'. Please try again!0");
                    return -1;

            }
            return 1;
        }

        //Move rover into left direction

        public int TurnLeft()
        {
            switch (roverDirection)
            {
                case "N":
                    roverDirection = "W";
                    break;
                case "E":
                    roverDirection = "N";
                    break;
                case "S":
                    roverDirection = "E";
                    break;
                case "W":
                    roverDirection = "S";
                    break;

                default:
                    Console.WriteLine("Invalid Direction. Valid Directions are: 'N','S','E','W'. Please try again!");
                    return -1;

            }
            return 1;

        }

    }


}